package soc.ms.mssnaps.payload.requests;

public record UserDownloadImageRequest(
        String userEmail) {
}

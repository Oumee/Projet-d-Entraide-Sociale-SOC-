package soc.ms.mssnaps.payload.requests;

public record DownloadImageRequest(
        String imageId) {
}

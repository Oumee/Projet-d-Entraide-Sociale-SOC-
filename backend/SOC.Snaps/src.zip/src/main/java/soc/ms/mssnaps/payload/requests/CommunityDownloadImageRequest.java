package soc.ms.mssnaps.payload.requests;

public record CommunityDownloadImageRequest(
        String communityName) {
}

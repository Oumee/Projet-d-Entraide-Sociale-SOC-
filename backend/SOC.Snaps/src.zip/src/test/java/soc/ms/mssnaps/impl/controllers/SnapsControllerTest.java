package soc.ms.mssnaps.impl.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import soc.ms.msdatamongodb.data.SocImage;
import soc.ms.mssnaps.impl.services.SnapsServiceImpl;
import soc.ms.mssnaps.interfaces.services.ISnapsServices;
import soc.ms.mssnaps.payload.requests.DownloadImageRequest;
import soc.ms.mssnaps.payload.respones.ImageInfoResponse;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Date;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SnapsController.class)
public class SnapsControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private SnapsServiceImpl iSnapsServices;

    SocImage snap;
    ImageInfoResponse res;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        snap = new SocImage("idrc56755", "test@gmail.com", "SOS", "test.png", 54L,
                "C:\\Users\\gx178\\Pictures\\Screenshot 2023-08-07 123649.png", "fileencodedto64", "png",
                new Date(), new Date());

        // Create a valid ImageInfoResponse
        res = new ImageInfoResponse("idrc56755", "test@gmail.com", "SOS", "test.png", 54L,
                "fileencodedto64", "png", new Date(), new Date());
    }

    @Test
    void uploadSnap() throws Exception {

    }

    @Test
    void downloadImage() throws Exception {

    }

    @Test
    void testGetImageInfo() throws Exception {
        String imageId = "testImageId";
        DownloadImageRequest request = new DownloadImageRequest(imageId);
        ImageInfoResponse mockResponse = new ImageInfoResponse("", "", "", "", 54L, "", "", new Date(), new Date());

        when(iSnapsServices.getImageInfo(imageId)).thenReturn(mockResponse);

        mockMvc.perform(get("/api/snaps/info")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(content().json(objectMapper.writeValueAsString(mockResponse)));

        verify(iSnapsServices, times(1)).getImageInfo(imageId);
    }

    @Test
    void SnapsGetAll() throws Exception {

    }

    @Test
    void getAllImagesUploadedBy() throws Exception {

    }

    @Test
    void getAllImagesForCommunity() throws Exception {

    }

    @AfterEach
    void clearUp() {

    }
}

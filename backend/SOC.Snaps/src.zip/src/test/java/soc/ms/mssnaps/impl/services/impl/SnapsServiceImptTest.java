package soc.ms.mssnaps.impl.services.impl;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestTemplate;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;
import soc.ms.msdatamongodb.data.SocImage;
import soc.ms.msdatamongodb.repository.ISocSnapsRepository;
import soc.ms.mssnaps.interfaces.services.ISnapsServices;
import soc.ms.mssnaps.payload.respones.ImageDataResponse;
import soc.ms.mssnaps.payload.respones.ImageInfoResponse;
import soc.ms.mssnaps.impl.services.SnapsServiceImpl;

import java.util.Date;
import java.util.Optional;
import java.util.stream.Stream;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

@DataMongoTest
public class SnapsServiceImptTest {
    @Mock
    private ISocSnapsRepository iSocSnapsRepository;
    @InjectMocks
    private SnapsServiceImpl snapsServiceImpl;
    AutoCloseable autoCloseable;
    SocImage snap;

    @BeforeEach
    void SetUp() {
        autoCloseable = MockitoAnnotations.openMocks(this);
        snap = new SocImage("idrc56755", "test@gmail.com", "SOS", "test.png", 54L, "C:\\Users\\gx178\\Pictures\\Screenshot 2023-08-07 123649.png", "fileencodedto64", "png", new Date(), new Date());

    }

    @AfterEach
    void cleanUp() throws Exception {
        autoCloseable.close();
    }

    @Test
    void testGetImageInfo() {
        // Mock the repository to return the snap when the id is queried
        when(iSocSnapsRepository.findById("idrc56755")).thenReturn(Optional.of(snap));

        // Call the service method
        ImageInfoResponse response = snapsServiceImpl.getImageInfo("idrc56755");

        // Assert that the response matches the expected values
        assertThat(response.label()).isEqualTo(snap.getLabel());
        assertThat(response.id()).isEqualTo(snap.getId());
    }
}
